# Csj Jeager

 - csj server bot on discord
 - its goal is to play music based on spotify and youtube as well as other streaming banks
 - least version `6.7` 
 


## How to install
- first `install node` in the best supported version, then run the following command in the terminal  `node i discord.js`  
- then put the token in the **`.env`** file where it will be pulled by the index

	[wax-command-handler](https://www.npmjs.com/package/wax-command-handler)

	![image](https://user-images.githubusercontent.com/87165376/213886802-cec4e549-892a-4aff-92a5-e7311f7083fd.png)

	**put the bot on your server using this link** ::> [This one link](https://discord.com/api/oauth2/authorize?client_id=1065991456793309204&permissions=8&scope=bot)


	**use** `/help` **pair to see command list**
	

---
 [Csj Server](https://discord.gg/K3Jnu2A5YP)

collaboration of [Slondo](https://github.com/odnols) 

----

